#pragma once
#include "CCharacter.h"

class CMiss : public CCharacter
{
public:
	void Update() {};
	void Render() {};
};
