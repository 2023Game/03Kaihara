#include "CSound.h"

int CSound::mNum = 0;
IXAudio2 *CSound::mpXAudio = 0;
IXAudio2MasteringVoice *CSound::mpMasterVoice = 0;


